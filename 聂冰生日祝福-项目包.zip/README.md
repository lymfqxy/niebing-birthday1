# 一份迟交的周测试卷 · 聂老师生日祝福

一个**单文件网页**：打开后是一张仿高中数学周测卷，五道题里藏着给聂老师的生日祝福。所有样式、脚本、图形都在 `index.html` 里，不依赖任何外部网络资源。

## 文件说明

- `index.html` —— 成品网页，双击即可在浏览器打开
- `preview.png` —— 手机宽度下的整页预览图（链接打不开时可直接发这张）

## 推荐路线：GitHub + Cloudflare Pages

这是最稳的公开方式：GitHub 只负责存代码，Cloudflare Pages 负责生成公网链接。

### 第一步：上传到 GitHub

1. 登录 GitHub，点右上角 **+ → New repository**。
2. 仓库名填 `niebing-birthday`，选 **Public**（私有仓库也能连 Cloudflare，但首次授权会多一步；公开最省事），点 **Create repository**。
3. 在仓库页点 **uploading an existing file**。
4. 把 **`index.html` 和 `preview.png` 两个文件**拖进去（不要只传 ZIP，Cloudflare 不会自动解压）。
5. 点 **Commit changes**。

确认仓库根目录能直接看到 `index.html`，不是在某个子文件夹里。

### 第二步：Cloudflare Pages 连接仓库

1. 登录 Cloudflare Dashboard。
2. 左侧 **Workers & Pages → Create application → Pages → Connect to Git**。
3. 首次使用会要求授权 GitHub：点 **Install & Authorize**，只勾选 `niebing-birthday` 这个仓库即可。
4. 选中 `niebing-birthday`，点 **Begin setup**。
5. 填写：
   - **Project name**：`niebing-birthday`（最终链接就是 `niebing-birthday.pages.dev`）
   - **Production branch**：`main`
   - **Framework preset**：`None`
   - **Build command**：留空（如果页面强制要求填，填 `exit 0`）
   - **Build output directory**：`/`
6. 点 **Save and Deploy**。
7. 等 1—2 分钟，部署完成，得到：
   `https://niebing-birthday.pages.dev`

### 第三步：先测试，再发送

用**你自己的手机流量**（不要只连 Wi-Fi）打开 `https://niebing-birthday.pages.dev`，确认：

- 能正常打开，不是“无法访问”；
- 页面能滚动，题目能点；
- 压轴题的手电筒图能画出来。

确认没问题，再把链接发给老师。微信里如果提示“非微信官方网页”，点右上角 **继续访问**。

## 备选：GitHub Pages（不推荐）

GitHub 本身可以打开，但本机实测 `github.io` 和 `raw.githubusercontent.com` 在当前网络下都连不上。如果你还是想试：

- Settings → Pages → Source 选 **Deploy from a branch** → **main / (root)** → Save
- 等 1—2 分钟，得到 `https://<用户名>.github.io/niebing-birthday/`
- **务必先用自己的手机测试**，打不开就不要发给老师。

如果 Cloudflare Pages 也打不开，最后兜底：

1. 直接发 `preview.png` 长图（微信里 100% 能看）；
2. 用手机录一段 30 秒的滚动演示视频，微信直接发。

## 本地打开

双击 `index.html`，用 Edge / Chrome 打开即可。

## 修改文案

用记事本或 VS Code 打开 `index.html`，搜索下面的关键词即可修改：

| 搜索 | 含义 |
|---|---|
| `徐州中学` | 学校名 |
| `高三(16)班` | 班级 |
| `董晨曦` | 你的名字 |
| `聂老师` | 对老师的称呼 |
| `42 岁` | 老师年龄 |
| `淮安` | 老师现在所在城市 |
| `2021—2024` | 高中三年 |
| `<div class="letter">` | 结尾那封信 |

改完保存，刷新浏览器即可。改完记得重新上传 `index.html`，Cloudflare Pages 会自动重新部署。

## 预览模式

在网页地址后面加 `?static=1`，会一次性展开所有题目、答案和印章，方便截图检查。

例如：`index.html?static=1`

## 发送建议

- **时间**：11 月 11 日早上发，不要卡 0 点（老师 42 岁，早上看到比半夜被震醒更妥帖）。
- **附言**可以写：

  > 聂老师，生日快乐！给您做了个小东西，点开慢慢往下滑。
  > 2024届16班 董晨曦

- 发完链接后，可以再补一张 `preview.png`，防止老师那边打不开。

## 设计说明

- 单文件、零外部依赖，微信内置浏览器可打开。
- 手机竖屏优先，桌面端居中显示。
- 所有动画在滚动到对应题目时触发；压轴题是一幅参数方程画出的“手电筒照试卷”。
- 彩蛋：第 42 次周测（老师今年 42 岁）、11 月 11 日的四个 1、压轴题 129 分（凑满 150）。